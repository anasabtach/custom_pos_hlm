<?php

namespace App\Interfaces\Admin;

interface PosInterface
{
    // Your interface methods here
}