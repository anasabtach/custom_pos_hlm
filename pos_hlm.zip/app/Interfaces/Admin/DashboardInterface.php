<?php

namespace App\Interfaces\Admin;



interface DashboardInterface
{   
    // public function getBrands(): Collection;
    
    // public function store(array $data): Brand;

    // public function edit(string $category_id):Brand;

    // public function delete(string $category_id):bool;

    // public function update(array $arr):bool;
}
