<?php

namespace App\Repository\Admin;

use App\Interfaces\Admin\DashboardInterface;
use App\Models\Brand;
use Illuminate\Database\Eloquent\Collection;

class DashboardRepository implements DashboardInterface
{

}
