

jQuery("#customdashboard").on('click', function(){	

  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow0').css('display','block');
  } else {
    jQuery('.permissionsallow0').css('display','none');
  }
  
});
jQuery("#custommedia").on('click', function(){	

  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow1').css('display','block');
  } else {
    jQuery('.permissionsallow1').css('display','none');
  }
  
});
jQuery("#customUnits").on('click', function(){	

  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow2').css('display','block');
  } else {
    jQuery('.permissionsallow2').css('display','none');
  }
  
});
jQuery("#customVariation").on('click', function(){	

  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow3').css('display','block');
  } else {
    jQuery('.permissionsallow3').css('display','none');
  }
  
});
jQuery("#customBrands").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow4').css('display','block');
  } else {
    jQuery('.permissionsallow4').css('display','none');
  }
});
jQuery("#customCategory").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow5').css('display','block');
  } else {
    jQuery('.permissionsallow5').css('display','none');
  }
});
jQuery("#customReviews").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow6').css('display','block');
  } else {
    jQuery('.permissionsallow6').css('display','none');
  }
});
jQuery("#customBarcode").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow7').css('display','block');
  } else {
    jQuery('.permissionsallow7').css('display','none');
  }
});

jQuery("#customProduct").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow8').css('display','block');
  } else {
    jQuery('.permissionsallow8').css('display','none');
  }
});
jQuery("#customStock").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow9').css('display','block');
  } else {
    jQuery('.permissionsallow9').css('display','none');
  }
});
jQuery("#customStockt").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow10').css('display','block');
  } else {
    jQuery('.permissionsallow10').css('display','none');
  }
});
jQuery("#customPurchase").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow11').css('display','block');
  } else {
    jQuery('.permissionsallow11').css('display','none');
  }
});
jQuery("#customOrders").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow12').css('display','block');
  } else {
    jQuery('.permissionsallow12').css('display','none');
  }
});
jQuery("#customSale").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow13').css('display','block');
  } else {
    jQuery('.permissionsallow13').css('display','none');
  }
});
jQuery("#customQuotations").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow14').css('display','block');
  } else {
    jQuery('.permissionsallow14').css('display','none');
  }
});

jQuery("#customSalert").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow15').css('display','block');
  } else {
    jQuery('.permissionsallow15').css('display','none');
  }
});
jQuery("#customPurchasert").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow16').css('display','block');
  } else {
    jQuery('.permissionsallow16').css('display','none');
  }
});
jQuery("#customAdmins").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow17').css('display','block');
  } else {
    jQuery('.permissionsallow17').css('display','none');
  }
});
jQuery("#customBiller").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow18').css('display','block');
  } else {
    jQuery('.permissionsallow18').css('display','none');
  }
});
jQuery("#customSupplier").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow19').css('display','block');
  } else {
    jQuery('.permissionsallow19').css('display','none');
  }
});

jQuery("#customCustomer").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow20').css('display','block');
  } else {
    jQuery('.permissionsallow20').css('display','none');
  }
});
jQuery("#customAccounts").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow21').css('display','block');
  } else {
    jQuery('.permissionsallow21').css('display','none');
  }
});
jQuery("#customBalances").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow22').css('display','block');
  } else {
    jQuery('.permissionsallow22').css('display','none');
  }
});
jQuery("#customTrial").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow23').css('display','block');
  } else {
    jQuery('.permissionsallow23').css('display','none');
  }
});
jQuery("#customCashf").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow24').css('display','block');
  } else {
    jQuery('.permissionsallow24').css('display','none');
  }
});
jQuery("#customPaymentA").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow25').css('display','block');
  } else {
    jQuery('.permissionsallow25').css('display','none');
  }
});
jQuery("#customExpenses").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow26').css('display','block');
  } else {
    jQuery('.permissionsallow26').css('display','none');
  }
});
jQuery("#customExpensest").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow27').css('display','block');
  } else {
    jQuery('.permissionsallow27').css('display','none');
  }
});
jQuery("#customProfit").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow28').css('display','block');
  } else {
    jQuery('.permissionsallow28').css('display','none');
  }
});
jQuery("#customPurchaser").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow29').css('display','block');
  } else {
    jQuery('.permissionsallow29').css('display','none');
  }
});
jQuery("#customSaleR").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow30').css('display','block');
  } else {
    jQuery('.permissionsallow30').css('display','none');
  }
});
jQuery("#customSupplierR").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow31').css('display','block');
  } else {
    jQuery('.permissionsallow31').css('display','none');
  }
});
jQuery("#customCustomerR").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow32').css('display','block');
  } else {
    jQuery('.permissionsallow32').css('display','none');
  }
});
jQuery("#customStockR").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow33').css('display','block');
  } else {
    jQuery('.permissionsallow33').css('display','none');
  }
});
jQuery("#customAdjustmentR").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow34').css('display','block');
  } else {
    jQuery('.permissionsallow34').css('display','none');
  }
});
jQuery("#customOUTStock").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow35').css('display','block');
  } else {
    jQuery('.permissionsallow35').css('display','none');
  }
});
jQuery("#customStockALERT").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow36').css('display','block');
  } else {
    jQuery('.permissionsallow36').css('display','none');
  }
});
jQuery("#custommExpenseR").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow37').css('display','block');
  } else {
    jQuery('.permissionsallow37').css('display','none');
  }
});
jQuery("#customBSGeneral").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow38').css('display','block');
  } else {
    jQuery('.permissionsallow38').css('display','none');
  }
});
jQuery("#customBSPOS").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow39').css('display','block');
  } else {
    jQuery('.permissionsallow39').css('display','none');
  }
});
jQuery("#customBSEmail").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow40').css('display','block');
  } else {
    jQuery('.permissionsallow40').css('display','none');
  }
});
jQuery("#customBSSMS").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow41').css('display','block');
  } else {
    jQuery('.permissionsallow41').css('display','none');
  }
});
jQuery("#customNotification").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow42').css('display','block');
  } else {
    jQuery('.permissionsallow42').css('display','none');
  }
});
jQuery("#customBSInvoice").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow43').css('display','block');
  } else {
    jQuery('.permissionsallow43').css('display','none');
  }
});
jQuery("#customBarcodes").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow44').css('display','block');
  } else {
    jQuery('.permissionsallow44').css('display','none');
  }
});
jQuery("#customEmaila").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow45').css('display','block');
  } else {
    jQuery('.permissionsallow45').css('display','none');
  }
});
jQuery("#customWBGeneral").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow46').css('display','block');
  } else {
    jQuery('.permissionsallow46').css('display','none');
  }
});
jQuery("#customcustomWBTheme").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow47').css('display','block');
  } else {
    jQuery('.permissionsallow47').css('display','none');
  }
});
jQuery("#customWBSEO").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow48').css('display','block');
  } else {
    jQuery('.permissionsallow48').css('display','none');
  }
});
jQuery("#customWBLogin").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow49').css('display','block');
  } else {
    jQuery('.permissionsallow49').css('display','none');
  }
});
jQuery("#customAPPGeneral").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow50').css('display','block');
  } else {
    jQuery('.permissionsallow50').css('display','none');
  }
});
jQuery("#customAPMenu").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow51').css('display','block');
  } else {
    jQuery('.permissionsallow51').css('display','none');
  }
});
jQuery("#customAPNotification").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow52').css('display','block');
  } else {
    jQuery('.permissionsallow52').css('display','none');
  }
});
jQuery("#customAPPLOGIN").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow53').css('display','block');
  } else {
    jQuery('.permissionsallow53').css('display','none');
  }
});
jQuery("#customLanguage").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow54').css('display','block');
  } else {
    jQuery('.permissionsallow54').css('display','none');
  }
});
jQuery("#customCurrency").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow55').css('display','block');
  } else {
    jQuery('.permissionsallow55').css('display','none');
  }
});
jQuery("#customPayementMethod").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow56').css('display','block');
  } else {
    jQuery('.permissionsallow56').css('display','none');
  }
});
jQuery("#customShippingmethod").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow57').css('display','block');
  } else {
    jQuery('.permissionsallow57').css('display','none');
  }
});
jQuery("#customTax").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow58').css('display','block');
  } else {
    jQuery('.permissionsallow58').css('display','none');
  }
});
jQuery("#customCoupons").on('click', function(){	
  if(jQuery(this).is(":checked")) {
    jQuery('.permissionsallow59').css('display','block');
  } else {
    jQuery('.permissionsallow59').css('display','none');
  }
});