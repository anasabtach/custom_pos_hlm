$('#brand_form').validate({
    rules:{
        brand_name:{
            required:true,
            maxlength:50
        }
    }
});